/*
SQLyog Community Edition- MySQL GUI v7.02 
MySQL - 5.1.26-rc-community : Database - ticketing_system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`ticketing_system` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ticketing_system`;

/*Table structure for table `agent` */

DROP TABLE IF EXISTS `agent`;

CREATE TABLE `agent` (
  `agent_id` int(11) NOT NULL,
  `agent_name` varchar(50) DEFAULT NULL,
  `skillset` varchar(50) DEFAULT NULL,
  `availability` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `agent` */

insert  into `agent`(`agent_id`,`agent_name`,`skillset`,`availability`) values (101,'sai','java','busy'),(102,'ravi','sql','busy'),(103,'sarath','mysql','busy'),(104,'venu','python','available');

/*Table structure for table `ticket` */

DROP TABLE IF EXISTS `ticket`;

CREATE TABLE `ticket` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) DEFAULT NULL,
  `issue_description` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `priority` varchar(20) DEFAULT NULL,
  `assigned_agent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `assigned_agent_id` (`assigned_agent_id`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`assigned_agent_id`) REFERENCES `agent` (`agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `ticket` */

insert  into `ticket`(`ticket_id`,`customer_name`,`issue_description`,`status`,`priority`,`assigned_agent_id`) values (3,'ravi','ksdnf akjnf','agent assigned','none',102),(4,'siva','lkasd kajsd','agent assigned','none',103),(6,'sai','sj aj sakjakj k s sjaj','agent assigned','none',101);

/*Table structure for table `tickethistory` */

DROP TABLE IF EXISTS `tickethistory`;

CREATE TABLE `tickethistory` (
  `history_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_description` text,
  PRIMARY KEY (`history_id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `tickethistory_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `tickethistory` */

insert  into `tickethistory`(`history_id`,`ticket_id`,`update_date`,`update_description`) values (3,6,'2024-07-19 11:37:54','ticket created'),(4,6,'2024-07-19 11:38:05','ticket is assigned and the agent id is: 101');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
