package casestudy;


import java.sql.*;
import java.util.*;
import javax.annotation.Generated;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 91756
 */
public class TicketingSystem {
    static Scanner sc=new Scanner(System.in);
    static void createNewTicket()
    {
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            PreparedStatement ps=c.prepareStatement("insert into ticket"
                    + "(customer_name,issue_description,status,priority"
                    + ") values(?,?,'agent not yet asigned','none')",Statement.RETURN_GENERATED_KEYS);
            
        System.out.print("name: ");
        String customerName=sc.nextLine().trim();
        System.out.println();
        System.out.print("write your issue: ");
        String issueDescription=sc.nextLine().trim();
            ps.setString(1, customerName);
            ps.setString(2,issueDescription);
            
            int z=ps.executeUpdate();
            
            if(z>=1) 
            {
                ResultSet rs=ps.getGeneratedKeys();
                rs.next();
                System.out.println("ticket created successfully and your ticket id is: "+rs.getInt(1));
                addTicketHistory(rs.getInt(1),"ticket created");
            }
            else System.out.println("ticket is not created......please try again");
            
            
        }
        catch (Exception e)
                {
                    System.out.println(e);
                }
        
         System.out.println("-------------------------------------------------------------"+"\n"+"\n");
         menu();
        
        
    }
    static void viewTicket()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            PreparedStatement ps=c.prepareStatement("select *from ticket where ticket_id=?");
            System.out.print("enter your ticket id: ");
            int tid=sc.nextInt();
            ps.setInt(1, tid);
            System.out.println();
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                System.out.println("ticket id: "+rs.getInt(1));
                System.out.println("name: "+rs.getString(2));
                System.out.println("issue: "+rs.getString(3));
                System.out.println("status: "+rs.getString(4));
                
            }
            else
            {
                System.out.println("ticket not found");
            }
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
         System.out.println("-------------------------------------------------------------"+"\n"+"\n");
         menu();
    }
    static void updateTicketInfo()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            System.out.print("enter your ticket id: ");
            int tid=sc.nextInt();
            sc.nextLine();
            System.out.println();
            System.out.print("enter the status of the given ticket id: ");
            String sts=sc.nextLine().trim();
            System.out.println();
            System.out.print("set the priority level ticket: ");
            String prty=sc.nextLine().trim();
            System.out.println();
            PreparedStatement ps=c.prepareStatement("update ticket set status=?,priority=?where ticket_id=?");
            ps.setString(1,sts);
            ps.setString(2,prty);
            ps.setInt(3,tid);
            int z=ps.executeUpdate();
            if (z>=1) 
            {
                System.out.println("updated successfully");
                addTicketHistory(tid,"ticket status is updated to"+sts+"and priority is updated to"+prty);
            }
            else System.out.println("check your ticket id and try again with a valid ticket id");
        }
        
        catch(InputMismatchException e)
        {
            System.out.println("enter valid details");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
         System.out.println("-------------------------------------------------------------"+"\n"+"\n");
         menu();
    }
    static void deleteTicket()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            System.out.print("enter your ticket id to delete: ");
            int tid=sc.nextInt();
            sc.nextLine();
            System.out.println(); 
            PreparedStatement ps=c.prepareStatement("delete from ticket where ticket_id=?");
            PreparedStatement ps1=c.prepareStatement("delete from tickethistory where ticket_id=?");
            ps1.setInt(1, tid);
            ps.setInt(1, tid);
            ps1.executeUpdate();
            PreparedStatement ps2=c.prepareStatement("select assigned_agent_id from ticket where ticket_id=?");
            ps2.setInt(1, tid);
            ResultSet rs=ps2.executeQuery();
            if (rs.next())
            {
                PreparedStatement ps3=c.prepareStatement("update agent set availability='available' where agent_id=?");
                ps3.setInt(1,rs.getInt(1));
                ps3.executeUpdate();
            }
            
            
            
            int z=ps.executeUpdate();
            if(z>=1) 
            {
                System.out.println("ticket deleted successfully");
                
                
            }
            else 
            {
                System.out.println("ticket not found please enter valid ticket id");
                
                deleteTicket();
            }
        }
        catch(InputMismatchException e)
        {
            System.out.println("enter valid ticket id and try again");
            
        }
        catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("-------------------------------------------------------------"+"\n"+"\n");
        menu();
         
    }
    static void addTicketHistory(int tid,String desc)
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            PreparedStatement ps=c.prepareStatement("insert into tickethistory (ticket_id,update_description"
                    + ") values(?,?)");
            ps.setInt(1, tid);
            ps.setString(2,desc);
            int z=ps.executeUpdate();
        }
        
        catch (Exception e) {
            System.out.println(e);
        }
        
        
         System.out.println("-------------------------------------------------------------"+"\n"+"\n");
         menu();
    }
    static void assignTickets()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            PreparedStatement ps1=c.prepareStatement("select ticket_id from ticket where assigned_agent_id is null");
            PreparedStatement ps2=c.prepareStatement("select agent_id from agent where availability='available'");
            ResultSet rs1=ps1.executeQuery();
            ResultSet rs2=ps2.executeQuery();
            while(rs1.next() && rs2.next())
            {
                PreparedStatement ps3=c.prepareStatement("update ticket set status='agent assigned',"
                        + "assigned_agent_id=? where ticket_id=?");
                ps3.setInt(1,rs2.getInt(1));
                ps3.setInt(2,rs1.getInt(1));
                PreparedStatement ps4=c.prepareStatement("update agent set availability='busy' where"
                        + " agent_id=?");
                ps4.setInt(1, rs2.getInt(1));
                int z=ps3.executeUpdate();
                int z1=ps4.executeUpdate();
                addTicketHistory(rs1.getInt(1),"ticket is assigned and the agent id is: "+rs2.getInt(1));
            }
            System.out.println("casestudy.TicketingSystem.assignTickets()");
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        
        
        System.out.println("-------------------------------------------------------------"+"\n"+"\n");
        menu();
    }
    static void ticketHistory()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3305/ticketing_system","root","root");
            System.out.print("enter your ticket id: ");
            int tid=sc.nextInt();
            sc.nextLine();
            System.out.println();
            PreparedStatement ps=c.prepareStatement("select *from tickethistory where ticket_id=?");
            ps.setInt(1, tid);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                System.out.println("history_id:"+rs.getInt(1)+"\n ticket_id:"+rs.getInt(2)+"\n update_date"+rs.getTimestamp(3)+"\n update_description"+rs.getString(4)); 
                
            }   
        
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        
         System.out.println("-------------------------------------------------------------"+"\n"+"\n");
         menu();
    }
    static void menu()
    {
       System.out.println("            Customer Support Ticketing System         ");
       System.out.println("---------------------------------------------------------");
       System.out.println("select your option:");
       System.out.println("1. create new ticket");
       System.out.println("2. view ticket details");
       System.out.println("3. update ticket status and priority");
       System.out.println("4. assign pending tickets to the agents");
       System.out.println("5. view ticket history");
       System.out.println("6. delete or close a ticket");
       System.out.println("7. view ticket history");
       System.out.println("8. exit");
       System.out.print("enter the option no:");
       int optn=sc.nextInt();
       sc.nextLine();
       switch(optn)
       {
           case(1):
               createNewTicket();
               break;
           case (2):
               viewTicket();
               break;
           case (3):
               updateTicketInfo();
               break;
           case (4):
               assignTickets();
               break;
           case (5):
               viewTicket();
               break;
           case (6):
               deleteTicket();
               break;
           case (7):
               ticketHistory();
               break;
           case (8):
               System.out.println("Thankyou...");
               break;
           default:
               System.out.println("enter a valid option......");
       }
        
    }
    public static void main(String ar[])
    {
        menu();
        
       
    }
}
